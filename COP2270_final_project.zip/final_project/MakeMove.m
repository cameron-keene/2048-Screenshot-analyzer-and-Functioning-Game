function [new_board,score] = MakeMove(board,direction)
    score = 0;        
    new_board = board;
end

