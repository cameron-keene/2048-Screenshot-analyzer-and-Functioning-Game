%Project 2048 Test File
clc; clear;

filename = input('Enter the name of the image: ', 's');
pixel = imread(filename);
imshow(pixel);

board_game = zeros(4,4);
board_game1 = AnalyzeScreenshot(board_game,pixel);
disp(board_game1);

direction = input('Enter up, down, left, right: ', 's');
[new_board2, b] = MakeMove(board_game1,direction);
disp(new_board2);
fprintf('The score is %g! \n', b);







